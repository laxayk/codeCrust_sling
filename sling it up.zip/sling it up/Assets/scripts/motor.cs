﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class motor : MonoBehaviour
{
    public Rigidbody car;
    public GameObject canvas;
    public float forwardspeed;
    public float angularspeed;
    public static bool ismoving = false;
   // public Transform pivot;
    public Wayptsys waypt;
    
    private bool rotating = false;
    // Start is called before the first frame update
    void Start()
    {
        car = GetComponent<Rigidbody>();
        
        rotating = false;
        
    }

    // Update is called once per frame
    void FixedUpdate()
    {
        if (ismoving)
        {
            car.velocity = transform.forward * forwardspeed * Time.deltaTime;
            if (Input.GetMouseButton(0) && (waypt.marktracker == 0 || waypt.marktracker == 3 || waypt.marktracker == 4 || waypt.marktracker == 6 || waypt.marktracker == 7))
            {

                if (Wayptsys.isinrange == true)
                {
                    car.transform.RotateAround(waypt.marker.transform.position, transform.up, angularspeed * Time.deltaTime);
                    // transform.rotation = Quaternion.Slerp(transform.rotation, Quaternion.Euler(0, +20, 0), 0.05f);

                    car.velocity = Vector3.zero;
                }


            }
            if (Input.GetMouseButton(0) && (waypt.marktracker == 1 || waypt.marktracker == 2 || waypt.marktracker == 5 || waypt.marktracker == 8 || waypt.marktracker == 9))
            {
                if (Wayptsys.isinrange == true)
                {
                    car.transform.RotateAround(waypt.marker.transform.position, -transform.up, angularspeed * Time.deltaTime);
                    // transform.rotation = Quaternion.Slerp(transform.rotation, Quaternion.Euler(0, +20, 0), 0.05f);

                    car.velocity = Vector3.zero;
                }


            }
        }
      
        
    }
    public void startgame()
    {
        ismoving = true;
        canvas.SetActive(false);
    }

    /*private void OnCollisionEnter(Collision collision)
    {
        if(collision.gameObject.tag == "Death")
        {
            destroyy();
        }
    }*/

    private void OnPostRender()
    {
        GL.PushMatrix();
        //mat.SetPass(0);
        GL.LoadOrtho();

        GL.Begin(GL.LINES);
        GL.Color(Color.red);
        GL.Vertex(transform.position);
        GL.Vertex(waypt.marker.transform.position);
        GL.End();

        GL.PopMatrix();
    }

    public void destroyy()
    {

    }
}
