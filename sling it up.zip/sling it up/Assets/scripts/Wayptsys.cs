﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UIElements;


public class Wayptsys : MonoBehaviour
{
    public GameObject marker;

    public GameObject[] Mark;


    public static bool isinrange;
    public int marktracker;
    public int marknum ;
    public LayerMask layermask;
    public Transform nextspawn;
    public GameObject level;

    /*public GameObject Waypoint;*/


    // Update is called once per frame
    void Update()
    {
        
        if (marktracker == marknum)
        {
           
            marker.transform.position = Mark[marknum].transform.position;
            marker.transform.rotation = Mark[marknum].transform.rotation;
            marknum++;
        }
        RaycastHit hit;
        if(Physics.Raycast(transform.position, transform.forward, out hit, 15, layermask))
        {
            print("yesssss");
            marktracker++;
            isinrange = false;
        }
        RaycastHit check;
        if (Physics.Raycast(transform.position, -transform.right, out check, 15, layermask))
        {
            print("yesssss");
            isinrange = true;
        }
        Debug.DrawRay(transform.position, transform.forward * 15, Color.blue);
        Debug.DrawRay(transform.position, -transform.right * 15, Color.yellow);
        if(marktracker == 10)
        {
            Instantiate(level, nextspawn);
            marktracker = 0;
            marknum = 0;
        }

    }
   
}
