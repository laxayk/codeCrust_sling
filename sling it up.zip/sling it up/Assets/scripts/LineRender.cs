﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class LineRender : MonoBehaviour
{
    public LineRenderer linerenderer;
    private float count;
    private float dist;

    public Transform origin;
    public Transform destination;

    public float linedrawspeed;
    // Start is called before the first frame update
    void Start()
    {
        linerenderer = GetComponent<LineRenderer>();
       
    }

    // Update is called once per frame
    void Update()
    {
        if (Input.GetMouseButton(0) && motor.ismoving == true)
        {
            //linerenderer.SetVertexCount(2);
            linerenderer.positionCount = 2;
            linerenderer.SetPosition(0, origin.position);
            linerenderer.SetWidth(0.45f, 0.45f);
            dist = Vector3.Distance(origin.position, destination.position);
            if (count < dist)
            {
                count += 0.1f / linedrawspeed;
                float x = Mathf.Lerp(0, dist, count);
                Vector3 pointA = origin.position;
                Vector3 pointB = destination.position;
                Vector3 pointalong = x * Vector3.Normalize(pointB - pointA) + pointA;

                linerenderer.SetPosition(1, pointalong);
            }
        }
        if (Input.GetMouseButtonUp(0) && motor.ismoving == true)
        {
            //linerenderer.SetVertexCount(0);
            linerenderer.positionCount = 0;
        }
       
    }
}
