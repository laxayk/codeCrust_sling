﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.SceneManagement;

public class Explosion : MonoBehaviour
{
    public float cubeSize = 0.1f;
    public int cubesInRow = 8;
    public Color rgbColor;
   /* public Shader rgbShader;*/
    bool tick = false;
   // private Renderer rend;

    float cubesPivotDistance;
    Vector3 cubesPivot;

    public float explosionForce = 50f;
    public float explosionRadius = 4f;
    public float explosionUpwards = 0.3f;
    // Start is called before the first frame update
    void Start()
    {
        
        cubesPivotDistance = cubeSize * cubesInRow / 2;
        cubesPivot = new Vector3(cubesPivotDistance, cubesPivotDistance, cubesPivotDistance);
       
    }

    // Update is called once per frame
    void Update()
    {
       // StartCoroutine(afterexplosion());
    }
    private void OnCollisionEnter(Collision collision)
    {
        if(collision.gameObject.tag == "Death")
        {
            //tick = true;
            motor.ismoving = false;
            Invoke("restart", 2.5f);
            explode();
            
        }
    }
    

  /*  IEnumerator afterexplosion()
    {
        if(tick == true)
        {
            explode();
            yield return new WaitForSeconds(3);
            SceneManager.LoadScene(0);
        }
    }*/

    public void explode()
    {
        gameObject.SetActive(false);

        for (int i = 0; i < cubesInRow; i++)
        {
            for (int j = 0; j < cubesInRow; j++)
            {
                for (int k = 0; k < cubesInRow; k++)
                {
                    createPiece(i,j,k);
                    
                }
            }
        }

        Vector3 explosionPos = transform.position;

        Collider[] colliders = Physics.OverlapSphere(explosionPos, explosionRadius);

        foreach (Collider hit in colliders)
        {
            Rigidbody rb = hit.GetComponent<Rigidbody>();
            if(rb != null)
            {
                rb.AddExplosionForce(explosionForce, transform.position, explosionRadius, explosionUpwards);
            }
        }
       
    }

    void createPiece(int x, int y, int z)
    {
        GameObject piece;
        piece = GameObject.CreatePrimitive(PrimitiveType.Cube);

        piece.transform.position = transform.position + new Vector3(cubeSize * x, cubeSize * y, cubeSize * z) - cubesPivot;
        piece.transform.localScale = new Vector3(cubeSize, cubeSize, cubeSize);

        piece.AddComponent<Rigidbody>();
        piece.GetComponent<Rigidbody>().mass = cubeSize;
        // piece.AddComponent<Renderer>();
        piece.GetComponent<Renderer>().material.color = rgbColor;
       /* piece.GetComponent<Renderer>().material.shader = rgbShader;
        piece.GetComponent<Shader>().Equals(gameObject.tag == "Player");*/
       

    }
    void restart()
    {
      //  new WaitForSeconds(2);
        Scene scene = SceneManager.GetActiveScene();
        SceneManager.LoadScene(scene.name);
    }
}
